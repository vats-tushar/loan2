package com.thinkapi.loan_amortisation.dto.loanAmortization;

import lombok.Data;

@Data
public class AmortizedSchedule {
    private Long loanId;
    private Double installmentAmt;
    private Double principalAmt;
    private Double expectedPrincipal;
    private Double projectedIntAmt;
    private String dueDt;
}
