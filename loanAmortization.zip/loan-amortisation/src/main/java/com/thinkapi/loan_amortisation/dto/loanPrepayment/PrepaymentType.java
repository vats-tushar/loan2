package com.thinkapi.loan_amortisation.dto.loanPrepayment;

public enum PrepaymentType {
    PARTIAL,
    FULL
}
