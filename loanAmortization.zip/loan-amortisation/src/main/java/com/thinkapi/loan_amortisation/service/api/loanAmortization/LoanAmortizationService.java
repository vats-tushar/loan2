package com.thinkapi.loan_amortisation.service.api.loanAmortization;

import com.thinkapi.loan_amortisation.dto.accountDetails.AccountBalanceRequest;
import com.thinkapi.loan_amortisation.dto.accountDetails.AccountBalanceResponse;
import com.thinkapi.loan_amortisation.dto.loan.LoanRepaymentRequest;
import com.thinkapi.loan_amortisation.dto.loan.LoanRepaymentResponse;
import com.thinkapi.loan_amortisation.dto.loanAmortization.LoanAmortizationRequest;
import com.thinkapi.loan_amortisation.dto.loanAmortization.LoanAmortizationResponse;
import com.thinkapi.loan_amortisation.dto.transactionHistory.TransactionHistory;
import com.thinkapi.loan_amortisation.dto.transactionHistory.TransactionHistoryRequest;
import com.thinkapi.loan_amortisation.dto.transactionHistory.TransactionHistoryResponse;
import com.thinkapi.loan_amortisation.service.api.accountBalance.AccountBalanceService;
import com.thinkapi.loan_amortisation.service.api.loanRepayment.LoanRepaymentService;
import com.thinkapi.loan_amortisation.service.api.transactionHistory.TransactionHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LoanAmortizationService {
    @Autowired
    private AccountBalanceService accountBalanceService;

    @Autowired
    private TransactionHistoryService transactionHistoryService;

    @Autowired
    private LoanRepaymentService loanRepaymentService;

    public LoanAmortizationResponse getAmortization(LoanAmortizationRequest req){
        AccountBalanceRequest accReq = new AccountBalanceRequest();
        accReq.setAccountReference(req.getAccountReference());
        AccountBalanceResponse accBalance = accountBalanceService.getAccountBalance(accReq).block();
        System.out.println("Account Balance : " + accBalance.getAccountBalanceDetails().getBalance().getAmount().getAccountBalance());

        TransactionHistoryRequest trhReq = new TransactionHistoryRequest();
        trhReq.setAccountReference(req.getAccountReference());
        TransactionHistoryResponse tranHistory = transactionHistoryService.getTransactionHistory(trhReq).block();
        List<TransactionHistory> listHist = tranHistory.getTransactionHistory();
        for(int i=0; i<listHist.size(); i++){
            System.out.println("TransactionHistory : ");
            System.out.println(i+ " : " + listHist.get(i));
        }


        LoanRepaymentRequest repayReq = new LoanRepaymentRequest();
        repayReq.setLoanReference(req.getLoanReference());
        LoanRepaymentResponse repaySchedule = loanRepaymentService.getLoanRepayment(repayReq).block();
        System.out.println("Repay Schedule : " + repaySchedule.getRepaymentEvents());

        LoanAmortizationResponse tempL = new LoanAmortizationResponse();

        return tempL;
    }

    public double suggestEmiIncrease(double newSalary, double acBalance, TransactionHistoryResponse tranHist, double balanceCushion){
        double sumOfDebits =1.0;
        double sumOfCredits =1.0;
        double tempSugg = newSalary + acBalance + sumOfCredits - sumOfDebits -  balanceCushion;
        return tempSugg;
    }

}
