package com.thinkapi.loan_amortisation.dto.loan;

import lombok.Data;

@Data
public class RepaymentEvent {
    private Long penalPaid;
    private Long installmentAmt;
    private String originalDueDt;
    private Long principalPaid;
    private Long projectedIntAmt;
    private String dueDt;
    private Long interestDue;
    private Long penalDueAmount;
    private String paidDt;
    private Long principalAmt;
    private Long loanId;
    private Long interestPaid;
    private Long expectedPrincipal;
    private Long status;
}
