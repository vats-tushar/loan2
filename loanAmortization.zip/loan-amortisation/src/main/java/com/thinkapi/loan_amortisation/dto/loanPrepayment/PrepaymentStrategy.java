package com.thinkapi.loan_amortisation.dto.loanPrepayment;

public enum PrepaymentStrategy {
    REDUCE_TENURE,
    REDUCE_EMI
}
