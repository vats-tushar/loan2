
package com.thinkapi.loan_amortisation.dto.loanAmortization;
import lombok.Data;

import java.util.List;

@Data
public class LoanAmortizationResponse {
    private Double currentEmi;
    private Double suggestedEmi;
    private Double currentAmortizedValue;
    private Double newAmortizedValue;
    private Double outstandingPrincipal;
    private Long currentNoOfInst;
    private Long newNoOfInst;
    private Double monthlyExpenses; //parent
    private Double savingsOnInterest;
    private Double monthlyIncome; //parent
    private Double monthlySavings; //parent
    private List<AmortizedSchedule> newSchedule;
}