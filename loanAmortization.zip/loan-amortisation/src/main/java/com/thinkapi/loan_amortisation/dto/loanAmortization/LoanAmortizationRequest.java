package com.thinkapi.loan_amortisation.dto.loanAmortization;

import lombok.Data;

@Data
public class LoanAmortizationRequest {

    // Request params
    private Long loanReference;
    private Long accountReference;
    private double newSalary;
    private double balanceCushion;
    private Integer installmentPaid;

}

