package com.thinkapi.loan_amortisation.dto.loan;

import lombok.Data;

@Data
public class LoanDetails {
    private String loanRef;
}
