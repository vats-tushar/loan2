package com.thinkapi.loan_amortisation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoanAmortisationApplicationTests {

	@Test
	void contextLoads() {
	}

}
