package com.thinkapi.loan_amortisation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoanAmortisationApplication {

	public static void main(String[] args) {
		System.out.print("Hello");
		SpringApplication.run(LoanAmortisationApplication.class, args);
	}

}
