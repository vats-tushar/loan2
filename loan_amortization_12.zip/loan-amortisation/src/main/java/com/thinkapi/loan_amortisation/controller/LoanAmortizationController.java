package com.thinkapi.loan_amortisation.controller;

import com.thinkapi.loan_amortisation.dto.loanAmortization.LoanAmortizationRequest;
import com.thinkapi.loan_amortisation.dto.loanAmortization.LoanAmortizationResponse;
import com.thinkapi.loan_amortisation.exception.InvalidInputException;
import com.thinkapi.loan_amortisation.service.api.loanAmortization.LoanAmortizationService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SecurityRequirement(name="bearerAuth")
@RestController
@RequestMapping("api/loan")
public class LoanAmortizationController {

    private static final Logger logger = LoggerFactory.getLogger(LoanAmortizationController.class);
    private final LoanAmortizationService loanAmortizationService;

    public LoanAmortizationController(LoanAmortizationService loanAmortizationService) {
        this.loanAmortizationService = loanAmortizationService;
    }

    @GetMapping("/loanAmortization")
    public ResponseEntity<LoanAmortizationResponse> getAmortizationEmi(
            @RequestParam Long loanReference,
            @RequestParam Long accountReference,
            @RequestParam double newSalary,
            @RequestParam double balanceCushion,
            @RequestParam(required = false) Integer installmentPaid
    ) {
        logger.debug("Received getAmortizationEmi request: loanReference={}, accountReference={}, newSalary={}, balanceCushion={}, installmentPaid={}",
                loanReference, accountReference, newSalary, balanceCushion, installmentPaid);

        if(loanReference < 0) {
            throw new InvalidInputException("Loan reference cannot be negative.");
        }
        if(accountReference < 0) {
            throw new InvalidInputException("Account reference cannot be negative.");
        }
        if(newSalary < 0) {
            throw new InvalidInputException("New salary cannot be negative.");
        }
        if(balanceCushion < 0) {
            throw new InvalidInputException("Balance cushion cannot be negative.");
        }
        if(installmentPaid!=null && installmentPaid < 0) {
            throw new InvalidInputException("Installment paid cannot be negative.");
        }
        try {
            LoanAmortizationRequest req = new LoanAmortizationRequest();
            req.setLoanReference(loanReference);
            req.setAccountReference(accountReference);
            req.setNewSalary(newSalary);
            req.setBalanceCushion(balanceCushion);
            req.setInstallmentPaid((installmentPaid));

            logger.debug("LoanAmortizationRequest built: {}", req);
            LoanAmortizationResponse response = loanAmortizationService.getAmortization(req);
            logger.debug("LoanAmortizationResponse received: {}", response);
            return ResponseEntity.ok(response);
        } catch (Exception ex) {
            logger.error("Error occurred while processing getAmortizationEmi for loanReference: {}", loanReference, ex);
            return ResponseEntity.internalServerError().build();
        }
    }
}
