package com.thinkapi.loan_amortisation.controller;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.util.Date;

@RestController
@RequestMapping("/demo")
public class TokenController {

    @GetMapping("/generate-token")
    public String generateToken(@RequestParam String username) {
        String secret = "MYSUPERLONGSECRETKEY1234567890ABCDMYSUPERLONGSECRETKEY1234567890ABCD"; // same as application.properties
        SecretKey key = new SecretKeySpec(secret.getBytes(),"HmacSHA256");
        return Jwts.builder()
                .setSubject(username)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + 3600 * 1000)) // 1 hour
                .signWith(key, SignatureAlgorithm.HS256)
                .compact();
    }
}
